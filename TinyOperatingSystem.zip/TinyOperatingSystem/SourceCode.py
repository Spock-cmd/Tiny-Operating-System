# ===== DEPENDENCIES AND GLOBAL VARIABLES =====
import sys
import time
import random
import os

username = "ReyRey"
password = "1234"

# ===== SYSTEM UTILITIES =====
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

def progress_bar(min_time, max_time):
    total_time = random.uniform(min_time, max_time)
    steps = 20
    delay = total_time / steps
    for i in range(steps + 1):
        filled = i
        green = "\033[92m-\033[0m"
        red = "\033[91m-\033[0m"
        bar = green * filled + red * (steps - filled)
        percent = int((i / steps) * 100)
        sys.stdout.write(f"\r{bar} {percent}%")
        sys.stdout.flush()
        time.sleep(delay)

def login():
    global username, password
    print("User:", username)
    while True:
        cmd = input("Enter your password: ")
        if cmd == password:
            print()
            progress_bar(4, 6)
            print("\n\nWelcome to TinyOS,", username)
            return True
        else:
            print("\033[91m[SYSTEM] Invalid password.\033[0m")

# ===== TEXT ECHOER =====
def textecho():
    print("\n--- Text Echoer ---")
    print("Type anything to echo it.")
    print("Type 'back' to exit")
    while True:
        text = input("\nType something: ")
        if text == "back":
            return
        elif text == "cls":
            clear_screen()
            main_menu()
        elif text == "return":
            clear_screen()
            boot()
        else:
            if text:
                print("You typed:", text)
            else:
                print("You typed: __")

# ===== SYSTEM INFORMATION =====
def about():
    print(""" 
OS:        TinyOS
VERSION:   1.0
RAM:       32 KB

SYSTEM SOFTWARE INFORMATION:
PROGRAM      VERSION  TYPE      HELPER PROGRAM(s)    CAN EXECUTE        DEPENDENCY
boot         1.0      System                                            login system
login        1.1a     System                                            sys, time, random
main menu    1.0      System                         All CMD Programs   sys, os
text echoer  1.0      App                                               sys, os
about        2.1.2    System    HelperInfo                              dependencyInfo
calculator   1.1      App       add, sub, mult, div  Math Operations    Runtime Math
terminal     1.11     System                         Terminal Commands  sys, os
progressbar  1.0      System                                            sys, random

TinyOS       1.0      OS        All                  All                sys, time, random, os\n""")

# ===== CALCULATOR =====
def calc():
    def add(a, b): return a + b
    def sub(a, b): return a - b
    def mult(a, b): return a * b
    def div(a, b):
        if b == 0:
            print("\033[91m[SYSTEM] Division by zero is not allowed\033[0m")
            return None
        return a / b
    def safe(prompt):
        while True:
            try:
                return float(input(prompt))
            except ValueError:
                print("\033[91m[SYSTEM] Input must be a number\033[0m")

    print("\n--- CALCULATOR ---")
    print("1. Addition")
    print("2. Subtraction")
    print("3. Multiplication")
    print("4. Division")
    print("5. Back to menu")
    while True:
        choice = input("\n>> ")
        if choice == "1":
            x, y = safe("a: "), safe("b: ")
            print(add(x, y))
        elif choice == "2":
            x, y = safe("a: "), safe("b: ")
            print(sub(x, y))
        elif choice == "3":
            x, y = safe("a: "), safe("b: ")
            print(mult(x, y))
        elif choice == "4":
            x, y = safe("a: "), safe("b: ")
            result = div(x, y)
            if result is not None: print(result)
        elif choice == "5":
            return
        elif choice == "cls":
            clear_screen()
            main_menu()
        elif choice == "return":
            clear_screen()
            boot()
        else:
            print("\033[91m[SYSTEM] Unknown command.\033[0m")

# ===== TERMINAL =====
def terminal():
    global username, password
    print("\nWelcome to PyTextOS Terminal")
    print("Terminal version 1.1")
    while True:
        cmd = input("\nTERMINAL > ")
        if cmd == "ver":
            print("Terminal version 1.1")
        elif cmd == "os":
            print("TinyOS v1.0")
        elif cmd == "back":
            return
        elif cmd == "acc":
            print("User:", username)
            print("Pass:", password)
        elif cmd == "help":
            print("\nTerminal commands: ver | os | back | acc | help | echo <text> | cls | return")
        elif cmd.startswith("echo "):
            txt = cmd[5:]
            if txt.lower().endswith(" /u"):
                print(txt.upper())
            elif txt.lower().endswith(" /l"):
                print(txt.lower())
            elif txt.lower().endswith(" /s"):
                print(txt.swapcase())
            else:
                print(txt)
        elif cmd == "cls":
            clear_screen()
            main_menu()
        elif cmd == "return":
            clear_screen()
            boot()
        else:
            print(f"\033[91m[SYSTEM] Invalid command: {cmd}\033[0m")

# ===== SYSTEM ASSISTANCE =====
def helpmenu():
    print(""" 
   Welcome to TinyOS. A tiny operating system made with
python. This operating system has 5 built-in programs you
can run. It has a text capitalizer, calculator, terminal,
about, and the help menu.

COMMAND    DESCRIPTION                               PROGRAM
ver        Displays the version of the terminal      Terminal
os         Displays the os version                   Terminal
back       exit the current program                  Terminal, Text Echoer
acc        Displays the account information          Terminal
echo       Displays text in the terminal             Terminal
help       Shows help menu                           Terminal, Main Menu
1 - 6      Run a program assigned to a number        Main Menu
1 - 5      Mode select (5 exits the program)         Calculator
cls        Clears screen keeping the main menu CLI   All Programs
return     Restarts your system                      All Programs

OS PROGRAMS:
boot
login
main menu
text echoer
about
calc
terminal
help menu""")

# ===== PROGRAM LAINCHER =====
def main_menu():
    print("\n--- Main Menu ---")
    print("1. Text Echoer")
    print("2. About")
    print("3. Terminal")
    print("4. Calculator")
    print("5. Help Menu")
    print("6. Shutdown")
    print("--- Type a number ---\n")
    while True:
        cmd = input("MAIN MENU >> ")
        if cmd == "1": textecho()
        elif cmd == "2": about()
        elif cmd == "3": terminal()
        elif cmd == "4": calc()
        elif cmd == "5": helpmenu()
        elif cmd == "6": sys.exit()
        elif cmd == "cls":
            clear_screen()
            main_menu()
        elif cmd == "return":
            print("Restarting...")
            time.sleep(1)
            clear_screen()
            boot()
        elif not cmd:
            print()
        else:
            print("\033[91m[SYSTEM] Invalid command.\033[0m")

# ===== OS BOOT =====
def boot():
    while True:
        if login():
            while True:
                result = main_menu()
                if result == "6":
                    sys.exit()

if __name__ == "__main__":
    boot()